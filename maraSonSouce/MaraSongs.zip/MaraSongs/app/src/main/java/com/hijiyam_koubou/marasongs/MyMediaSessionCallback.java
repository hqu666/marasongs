package com.hijiyam_koubou.marasongs;

public class MyMediaSessionCallback {

}
